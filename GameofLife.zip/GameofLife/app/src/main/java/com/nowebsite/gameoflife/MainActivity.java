package com.nowebsite.gameoflife;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Rect;
import android.graphics.RectF;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;

import java.util.Random;
import java.util.Timer;
import java.util.TimerTask;

public class MainActivity extends AppCompatActivity {

    // константы
    static final int FIELD_SIZE = 50;
    static final int LIFE_SIZE = 21;
    static final int STEP_TIME = 250;
    Paint p, p1, p2; // кисти
    boolean[][] lifeGeneration = new boolean[FIELD_SIZE][FIELD_SIZE];
    boolean[][] nextGeneration = new boolean[FIELD_SIZE][FIELD_SIZE];
    boolean goNextGeneration = false; // переключатель
    Random random = new Random();


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Холст для рисования
        DrawView drawView = new DrawView(this);

        LinearLayout layoutCells = findViewById(R.id.cells);
        // подключение холста
        layoutCells.addView(drawView);

        // кнопка "старт/стоп"
        Button startStopButton = findViewById(R.id.start_stop_button);
        startStopButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                goNextGeneration = !goNextGeneration;
                startStopButton.setText((goNextGeneration) ? "Stop" : "Start");

            }
        });

        // кнопка "рандом"
        Button randomizeButton = findViewById(R.id.ramdomize_button);
        randomizeButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                for(int x = 0; x < FIELD_SIZE; x++) {
                    for(int y = 0; y < FIELD_SIZE; y++) {
                        lifeGeneration[x][y] = random.nextBoolean(); // рандомное заполнение клеток жизнями
                    }
                }
                drawView.invalidate(); // перерисовка

            }
        });

        // отдельный поток для проверки переключателя
        Thread myThread = new Thread(new Runnable() {
            @Override
            public void run() {
                while(true) {
                    if(goNextGeneration) {
                        processOfLife();
                        drawView.invalidate();
                        try {
                            Thread.sleep(STEP_TIME);
                        } catch(InterruptedException e) {
                            e.printStackTrace();
                        }
                    }
                }
            }
        });
        myThread.start();
    }

    // процесс создания жизни
    void processOfLife() {
        for(int x = 0; x < FIELD_SIZE; x++) {
            for(int y = 0; y < FIELD_SIZE; y++) {
                int count = countNeighbors(x, y);
                nextGeneration[x][y] = lifeGeneration[x][y];
                nextGeneration[x][y] = (count == 3) ? true : nextGeneration[x][y];
                nextGeneration[x][y] = ((count < 2) || (count > 3)) ? false : nextGeneration[x][y];
            }
        }
        for(int x = 0; x < FIELD_SIZE; x++) {
            System.arraycopy(nextGeneration[x], 0, lifeGeneration[x], 0, FIELD_SIZE);
        }
    }
    // подсчёт соседей
    int countNeighbors(int x, int y) {
        int count = 0;
        for(int dx = -1; dx < 2; dx++) {
            for(int dy = -1; dy < 2; dy++) {
                int nX = x + dx;
                int nY = y + dy;
                nX = (nX < 0) ? FIELD_SIZE - 1 : nX;
                nY = (nY < 0) ? FIELD_SIZE - 1 : nY;
                nX = (nX > FIELD_SIZE - 1) ? 0 : nX;
                nY = (nY > FIELD_SIZE - 1) ? 0 : nY;
                count += (lifeGeneration[nX][nY]) ? 1 : 0;
            }
        }
        if(lifeGeneration[x][y]) {
            count--;
        }
        return count;
    }
    // класс холста
    class DrawView extends View {

        public DrawView(Context context) {
            super(context);
            p = new Paint();
            p1 = new Paint();
            p2 = new Paint();
        }

        @Override
        protected void onDraw(Canvas canvas) {
            super.onDraw(canvas);
            makeSimulation(canvas);
            drawCells(canvas);

        }
        // рисование клеточного поля
        private void makeSimulation(Canvas canvas) {
            p.setColor(Color.BLUE);
            p.setStrokeWidth(1);
            p.setStyle(Paint.Style.STROKE);
            for(int x = 0; x < FIELD_SIZE; x++) {
                for(int y = 0; y < FIELD_SIZE; y++) {
                    canvas.drawRect( + x * LIFE_SIZE, y * LIFE_SIZE, x * LIFE_SIZE + LIFE_SIZE, y * LIFE_SIZE + LIFE_SIZE, p);
                }
            }
        }
        // рисование жизней. Вторая кисть для очертания границ
        private void drawCells(Canvas canvas) {
            p1.setColor(Color.BLACK);
            p1.setStrokeWidth(1);
            p1.setStyle(Paint.Style.FILL);
            p2.setColor(Color.BLUE);
            p2.setStrokeWidth(1);
            p2.setStyle(Paint.Style.STROKE);
            for(int x = 0; x < FIELD_SIZE; x++) {
                for(int y = 0; y < FIELD_SIZE; y++) {
                    if(lifeGeneration[x][y]) {
                        canvas.drawRect( + x * LIFE_SIZE, y * LIFE_SIZE, x * LIFE_SIZE + LIFE_SIZE, y * LIFE_SIZE + LIFE_SIZE, p1);
                        // границы
                        canvas.drawRect( + x * LIFE_SIZE, y * LIFE_SIZE, x * LIFE_SIZE + LIFE_SIZE, y * LIFE_SIZE + LIFE_SIZE, p2);
                    }
                }
            }
        }
    }
}